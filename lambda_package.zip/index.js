// -------------------------------------
const { Client } = require('@notionhq/client');
const AWS = require('aws-sdk');
const s3 = new AWS.S3();

const response = {
    statusCode: 200,
    headers: { 
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Headers": "Content-Type",
        "Access-Control-Allow-Methods": "OPTIONS,POST"
    },
    isBase64Encoded: false,
    body: JSON.stringify({ result: "Success" })
};

const notion = new Client({ auth: 'secret_vxCZixTbzZn3eZzyk7QivNp8Si6nd1BHaVixHoKPX7U' });

exports.handler = async (event) => {
    try {
        console.log('Received event:', JSON.stringify(event, null, 2));
        
        // Check if event.body exists
        if (!event.body) {
            throw new Error('No request body received');
        }

        // Parse the body from API Gateway
        let body;
        try {
            body = JSON.parse(event.body);
            console.log(body)

        } catch (parseError) {
            console.error('Error parsing request body:', event.body);
            throw new Error('Invalid JSON in request body');
        }
        
        // logic to send more information to page in notion

        function formatDate(date) {
                       return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`;
              }
        let now = new Date();

        // Handle gasto type submissions separately
        if (body.type === 'gasto') {
            return await handleGastoSubmission(body, formatDate, now, notion);
        }

        // Handle deposit submissions
        if (body.type === 'deposito') {
            return await handleDepositoSubmission(body, formatDate, now, notion);
        }

        // Handle incidencia submissions
        if (body.type === 'incidencia') {
            return await handleIncidenciaSubmission(body, formatDate, now, notion);
        }

        // Handle encuesta (survey) submissions
        if (body.type === 'encuesta') {
            return await handleEncuestaSubmission(body, formatDate, now, notion);
        }

        let title = `Movimiento ${body.type} - ${formatDate(now)}`;
        
        let euros = (body.b20e*20)+(body.b10e*10)+(body.b5e*5)+(body.m2e*2)+(body.m1e*1)+(body.m50e*0.50)+(body.m20e*0.20)+(body.m10e*0.10)+(body.m5e*0.05)
        console.log(`euros: ${euros}`);

        let description = `Count de billetes: 20e = ${body.b20e}, 10e = ${body.b10e}, 5e = ${body.b5e} - Count de Monedas: 2e = ${body.m2e}, 1e = ${body.m1e}, 0.50e = ${body.m50e}, 0.20e = ${body.m20e}, 0.10e = ${body.m10e}, 0.05e = ${body.m5e}`
        console.log(`description: ${description}`);

        console.log('Creating Notion page now...');
                    // Create Notion page
        const newPage = await notion.pages.create({
                        parent: {
                            database_id: '18413ec8894180bca990fccf2854f9d6'
                        },
                        icon: {
                            type: "emoji",
                            emoji: "🟡"
                        },
                        properties: {
                            movement: {
                                title: [
                                    {
                                        text: {
                                            content: title
                                        }
                                    }
                                ]
                            },
                            type: {
                                select: {
                                    name: (() => {
                                        switch(body.type) {
                                          case "transito": return "transito";
                                          case "deposito": return "deposito";
                                          case "gasto": return "gasto";
                                          default: return "fondo caja";
                                        }
                                      })()
                                }
                            },
                            account: {
                                select: {
                                    name: 'cash'
                                }
                            },
                            euros: {
                                number: euros
                            },
                            mcf_user: {
                                select: {
                                    name: body.user
                                }
                            },
                            propiedad: {
                                select: {
                                    name: body.propiedad || 'unknown'
                                }
                            },
                            date_real: {
                                date: {
                                    start: formatDate(now)
                                }
                            }
                        }
                    }); 

         console.log(`Created page: ${newPage.id}`);

         // Add the description as a child block
         await notion.blocks.children.append({
            block_id: newPage.id,
            children: [
                {
                    "paragraph": {
                        "rich_text": [
                            {
                                "text": {
                                    "content": description
                                }
                            }
                        ]
                    }
                }
            ],
        });

        return response;

    } catch (error) {
        console.error('Error:', error);
        return {
            statusCode: 500,
            headers: {
                "Content-Type": "application/json",
                "Access-Control-Allow-Origin": "*",
                "Access-Control-Allow-Headers": "Content-Type",
                "Access-Control-Allow-Methods": "OPTIONS,POST"
            },
            body: JSON.stringify({
                error: "mcf-movimientosForm-v3 - Internal server error",
                message: error.message
            })
        };
    }
};

// Handle gasto (expense) submissions to Notion
async function handleGastoSubmission(body, formatDate, now, notion) {
    const DATABASE_ID = '18413ec8894180bca990fccf2854f9d6';

    const title = `Gasto ${body.propiedad} - ${body.concepto_mcf} - ${formatDate(now)}`;
    const description = `Concepto: ${body.concepto_proveedor}
Importe: ${body.importe_total} ${body.currency}
Fiscal: ${body.is_fiscal ? 'Si' : 'No'}
Inversion: ${body.es_inversion ? 'Si' : 'No'}`;

    console.log(`Creating gasto page: ${title}`);

    const newPage = await notion.pages.create({
        parent: {
            database_id: DATABASE_ID
        },
        icon: {
            type: "emoji",
            emoji: "💸"
        },
        properties: {
            movement: {
                title: [
                    {
                        text: {
                            content: title
                        }
                    }
                ]
            },
            type: {
                select: {
                    name: 'gasto'
                }
            },
            account: {
                select: {
                    name: 'cash'
                }
            },
            euros: {
                number: body.importe_total || 0
            },
            mcf_user: {
                select: {
                    name: body.mcf_user || 'unknown'
                }
            },
            date_real: {
                date: {
                    start: formatDate(now)
                }
            }
        }
    });

    console.log(`Created gasto page: ${newPage.id}`);

    // Add the description as a child block
    await notion.blocks.children.append({
        block_id: newPage.id,
        children: [
            {
                "paragraph": {
                    "rich_text": [
                        {
                            "text": {
                                "content": description
                            }
                        }
                    ]
                }
            }
        ],
    });

    return {
        statusCode: 200,
        headers: {
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Headers': 'Content-Type',
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            success: true,
            type: 'gasto',
            pageId: newPage.id,
            message: 'Gasto page created successfully in Notion'
        })
    };
}

// Handle deposit submissions
async function handleDepositoSubmission(body, formatDate, now, notion) {
    const DATABASE_ID = '18413ec8894180bca990fccf2854f9d6';

    const title = `Deposito a Cuenta - ${formatDate(now)}`;
    const description = `Deposito de ${body.euros} EUR a cuenta bancaria`;

    console.log(`Creating deposito page: ${title}`);

    const newPage = await notion.pages.create({
        parent: {
            database_id: DATABASE_ID
        },
        icon: {
            type: "emoji",
            emoji: "🏦"
        },
        properties: {
            movement: {
                title: [
                    {
                        text: {
                            content: title
                        }
                    }
                ]
            },
            type: {
                select: {
                    name: 'deposito'
                }
            },
            account: {
                select: {
                    name: body.account || 'cash'
                }
            },
            euros: {
                number: body.euros || 0
            },
            mcf_user: {
                select: {
                    name: body.mcf_user || 'unknown'
                }
            },
            propiedad: {
                select: {
                    name: body.propiedad || 'unknown'
                }
            },
            date_real: {
                date: {
                    start: formatDate(now)
                }
            }
        }
    });

    console.log(`Created deposito page: ${newPage.id}`);

    // Add the description as a child block
    await notion.blocks.children.append({
        block_id: newPage.id,
        children: [
            {
                "paragraph": {
                    "rich_text": [
                        {
                            "text": {
                                "content": description
                            }
                        }
                    ]
                }
            }
        ],
    });

    return {
        statusCode: 200,
        headers: {
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Headers': 'Content-Type',
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            success: true,
            type: 'deposito',
            pageId: newPage.id,
            message: 'Deposito page created successfully in Notion'
        })
    };
}

// Handle incidencia submissions to a separate Notion database
async function handleIncidenciaSubmission(body, formatDate, now, notion) {
    const DATABASE_ID = '19613ec8894180198e6ef1529ccf057d';

    // Use description as title, or fallback to generic title
    const title = body.description || `Incidencia ${body.propiedad} - ${formatDate(now)}`;

    console.log(`Creating incidencia page: ${title}`);

    // Build properties object
    const properties = {
        summary: {
            title: [
                {
                    text: {
                        content: title
                    }
                }
            ]
        },
        severity: {
            select: {
                name: body.severity || 'media'
            }
        },
        propiedad: {
            select: {
                name: body.propiedad || 'unknown'
            }
        },
        cost: {
            number: body.cost || 0
        },
        resolution: {
            select: {
                name: body.resolution || 'pendiente'
            }
        },
        incident_date: {
            date: {
                start: formatDate(now)
            }
        },
        found: {
            select: {
                name: body.found || 'otro'
            }
        }
    };

    // Only add machine if provided
    if (body.machine) {
        properties.machine = {
            select: {
                name: body.machine
            }
        };
    }

    const newPage = await notion.pages.create({
        parent: {
            database_id: DATABASE_ID
        },
        icon: {
            type: "emoji",
            emoji: "⚠️"
        },
        properties: properties
    });

    console.log(`Created incidencia page: ${newPage.id}`);

    return {
        statusCode: 200,
        headers: {
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Headers': 'Content-Type',
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            success: true,
            type: 'incidencia',
            pageId: newPage.id,
            message: 'Incidencia page created successfully in Notion'
        })
    };
}

// Handle encuesta (customer survey) submissions
async function handleEncuestaSubmission(body, formatDate, now, notion) {
    const DATABASE_ID = '2b413ec8894180e0ae5ee8c3699fa99a';

    const surveyId = body.survey_id || 'no-id';
    const title = `Encuesta ${body.location} - ${surveyId}`;

    console.log(`Creating encuesta page: ${title}`);

    const newPage = await notion.pages.create({
        parent: {
            database_id: DATABASE_ID
        },
        icon: {
            type: "emoji",
            emoji: "📋"
        },
        properties: {
            Name: {
                title: [
                    {
                        text: {
                            content: title
                        }
                    }
                ]
            },
            survey_id: {
                rich_text: [
                    {
                        text: {
                            content: surveyId
                        }
                    }
                ]
            },
            propiedad: {
                select: {
                    name: body.location || 'unknown'
                }
            },
            experience: {
                select: {
                    name: body.experience || 'unknown'
                }
            },
            cleanliness: {
                select: {
                    name: body.cleanliness || 'unknown'
                }
            },
            availability: {
                select: {
                    name: body.availability || 'unknown'
                }
            },
            recommend: {
                select: {
                    name: body.recommend || 'unknown'
                }
            },
            survey_date: {
                date: {
                    start: now.toISOString()
                }
            }
        }
    });

    console.log(`Created encuesta page: ${newPage.id}`);

    // Add comments as a child block if provided
    if (body.comments && body.comments.trim()) {
        await notion.blocks.children.append({
            block_id: newPage.id,
            children: [
                {
                    "paragraph": {
                        "rich_text": [
                            {
                                "text": {
                                    "content": `Comentarios: ${body.comments}`
                                }
                            }
                        ]
                    }
                }
            ],
        });
    }

    return {
        statusCode: 200,
        headers: {
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Headers': 'Content-Type',
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            success: true,
            type: 'encuesta',
            pageId: newPage.id,
            message: 'Encuesta submitted successfully to Notion'
        })
    };
}
